#include <iostream>
#include <math.h>

 double wih[4][2];
 double who[1][4];

double log_sigmoid(double weighted_input) {
    return (1/(1+exp(-weighted_input)));
}


double network_training(double input[2]) {

    //initialization of the weight matrices
  int i ;
  int j;
  for (i = 0; i < 4; i++) {
    
    for(j = 0; j < 2; j++) {
        std::cout << i << "," << j << ": ";
        double r = ((double) rand() / (RAND_MAX));
        wih[i][j] = r;
        std::cout << *wih[i,j] << " ";
    }
    std::cout <<"\n";
  }
  
    std::cout <<"\n";
    for(j = 0; j < 4; j++) {
        double r = ((double) rand() / (RAND_MAX));
        who[1][j] = r;
        std::cout << *who[i,j] << " ";
    }
    std::cout << "\n";

    //calculation of output of 2nd layer

    double yih[2];

    
  
  
  
  
  



}


int main() {
    
    double input[2] = {1.0, 2.0};
    network_training(input);

    return 0;
}

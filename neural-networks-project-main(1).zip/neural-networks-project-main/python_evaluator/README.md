# Python evaluation utility
Similar utility will be used to evaluate your solution.

```python
python3 evaluate.py -h
python3 evaluate.py ../actualPredictionsExample ../data/fashion_mnist_test_labels.csv
```
